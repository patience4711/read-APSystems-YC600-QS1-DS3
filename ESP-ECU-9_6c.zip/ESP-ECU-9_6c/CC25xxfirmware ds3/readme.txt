These firmwares are testversions for the DS3 inverter. 
They should work with yc600 and qs1 as well. 
However at this time we are not shure it will work wit mode than 2 inverters. 

If you happen to have more than 2 inverters, (can be mixed types) please report if this works.