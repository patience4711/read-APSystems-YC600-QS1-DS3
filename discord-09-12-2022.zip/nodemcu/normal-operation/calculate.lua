local str=...
local ix=0;local s_l=tonumber(string.sub(str,3,4),16)
local s_d=string.sub(str,43,2*s_l+2);local i_i=string.sub(s_d,1,12)
for x=1, inv_num do if i_i == inv_sn[x] then ix=x end end
trace("ix="..ix.." i_i="..i_i.." Heap="..node.heap())
if ix > 0 then
	local qs1=false;local o1=35;local o2=85;local o3=75;local o4=48;local o5=54
	if string.sub(s_d,1,2) == "80" then qs1=true;o1=61;o2=75;o3=85;o4=54;o5=48 end
	if t2[ix] >= tonumber(string.sub(s_d,o1,o1+3),16) then trace("Time");return end
	local d=inv_sn[ix]
	local function a2d(dc,dd)
		d=d..","..tonumber(string.format("%."..dc.."f",dd))
	end
	a2d(2,50000000/tonumber(string.sub(s_d,25,30),16))
	a2d(1,0.2752*tonumber(string.sub(s_d,21,24),16)-258.7)
	a2d(1,0.1873*tonumber(string.sub(s_d,57,60),16))
 	t1[ix]=t2[ix];t2[ix]=tonumber(string.sub(s_d,o1,o1+3),16)
	e11[ix]=e12[ix];e12[ix]=tonumber(string.sub(s_d,o2,o2+5),16)
	a2d(1,(e12[ix]-e11[ix])*8.311/(t2[ix]-t1[ix]))
	e21[ix]=e22[ix];e22[ix]=tonumber(string.sub(s_d,o3,o3+5),16)
	a2d(1,(e22[ix]-e21[ix])*8.311/(t2[ix]-t1[ix]))
	if qs1 then
		e31[ix]=e32[ix];e32[ix]=tonumber(string.sub(s_d,95,100),16)
		a2d(1,(e32[ix]-e31[ix])*8.311/(t2[ix]-t1[ix]))
		e41[ix]=e42[ix];e42[ix]=tonumber(string.sub(s_d,105,110),16)
		a2d(1,(e42[ix]-e41[ix])*8.311/(t2[ix]-t1[ix]))
	end
	a2d(2,e12[ix]*8.311/3600000);a2d(2,e22[ix]*8.311/3600000)
	if qs1 then
		a2d(2,e32[ix]*8.311/3600000);a2d(2,e42[ix]*8.311/3600000)
	end
	a2d(1,tonumber(string.sub(s_d,o4,o4)..string.sub(s_d,o4-3,o4-2),16)/160)
	a2d(1,tonumber(string.sub(s_d,o5,o5)..string.sub(s_d,o5-3,o5-2),16)/160)
	a2d(1,tonumber(string.sub(s_d,o4+1,o4+2)..string.sub(s_d,o4-1,o4-1),16)/48)
	a2d(1,tonumber(string.sub(s_d,o5+1,o5+2)..string.sub(s_d,o5-1,o5-1),16)/48)
	if qs1 then
		a2d(1,tonumber(string.sub(s_d,42,42)..string.sub(s_d,39,40),16)/160)
		a2d(1,tonumber(string.sub(s_d,36,36)..string.sub(s_d,33,34),16)/160)
		a2d(1,tonumber(string.sub(s_d,43,44)..string.sub(s_d,41,41),16)/48)
		a2d(1,tonumber(string.sub(s_d,37,38)..string.sub(s_d,35,35),16)/48)
	end
	trace(d);s_inv_d[ix]=d;assert(loadfile("upload.lua"))(d)
end
