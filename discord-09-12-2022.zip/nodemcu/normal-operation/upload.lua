local str=...
trace(node.heap())
local mqtt=mqtt.Client(node.chipid(),120,"","",1)
mqtt:connect(server,1883,false,
	function(conn) trace("Connected")
	mqtt:publish("ECU-DATA",str,0,0,function(client) 
		trace("Sent");mqtt:close();mqtt=nil;str=nil
	end)
end,
	function(conn,reason) trace("Connection failed "..reason)
end)
trace(node.heap())
