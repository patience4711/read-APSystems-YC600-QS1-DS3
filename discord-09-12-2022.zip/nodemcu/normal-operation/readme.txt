NODEMCU implementation of fake ECU 0.7

License CC BY-NC-SA 3.0: https://creativecommons.org/licenses/by-nc-sa/3.0/

Note: Only supports normal operation, for pairing use "pairing" set of scripts.

Setup:
Flash ESP8266 with attached firmware
Edit header of init.lua to include your wifi, local IP, inverter and
MQTT account information
Upload all the lua files to the ESP8266 (no ESP32 support yet)
Connect the radio device RX to D7, TX to D8 of the ESP

Operate:
If everything is setup correctly the ECU will start up and initialize your
radio device. During initializaton, the blue LED will be blinking. If 
everything goes OK the blue LED will lit and the application will start
quering your inverters. Data will be uploaded to MQTT (subscribe to
ECU-DATA, client id will be the chipID of your ESP). If you connect your
browser to the IP of your ESP a simple web interface will be shown. The last
2 messages sent to MQTT will be displayed there.

Troubleshooting:
If something does not work, enable tracing by flipping "trace_on" to "true"
in init.lua. When tracing is on (=true) the a file "trace.txt" will be 
generated on your ESP. Do not let tracing unncessary on as it will fill up 
your ESP storage and also kill the flash on the long run.

Inverter query time period is set to 1 min. If you want to change it,
edit init.lua and change the value of "u_delay".

Which script is doing what?

init.lua - NODEMCU start this program when powered on. If you want to regain
control, delete this within 5 sec of starting up your NODEMCU
initialize.lua - brings up the coordinator (fake ECU)
operate.lua - normal operation, queries inverters
calculate.lua - extracts measurement results from inverter response for YC600&1000
calculat2.lua - extracts measurement results from inverter response for DS3
upload.lua - uploads extracted values to MQTT server
h_check.lua - health (heap) check and reset counters
httpserv.lua - very simple http server

Avoid using ESPlorer:

ESPlorer has a problem with uploading lua scripts to NodeMCU. Please consider 
using an other tool, like https://www.npmjs.com/package/nodemcu-tool. If you 
still want to stick with ESPlorer, make sure you switch on "turbo mode" before 
uploading anything. Otherwise, scripts might get corrupted and your setup will 
disfunction. https://www.esp8266.com/viewtopic.php?f=22&t=1166&start=4 
