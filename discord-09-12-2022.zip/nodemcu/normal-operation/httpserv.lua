print("Starting HTTP server")
local srv=net.createServer(net.TCP)
srv:listen(80,function(conn)
	conn:on("receive",function(client,request)
		local path=string.match(request,"GET /(.+) HTTP")
		if path == nil or path == "" or path == "/" then
			local buff="<html><p>NodeMCU on ESP8266: "..node.chipid()
			buff=buff.."<p>Time: "..tmr.time().." Heap :"..node.heap()
			for j=1, inv_num do
				buff=buff.."<p>"..s_inv_d[j]
			end
			client:send(buff)
		end
	end)
	conn:on("sent",function(sck) sck:close() end)
end)
print("HTTP Server is running")
