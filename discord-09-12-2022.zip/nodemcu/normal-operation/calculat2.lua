local str=...
local ix=0;local s_l=tonumber(string.sub(str,3,4),16)
local s_d=string.sub(str,43,2*s_l+2);local i_i=string.sub(s_d,1,12)
for x=1, inv_num do if i_i == inv_sn[x] then ix=x end end
trace("ix="..ix.." i_i="..i_i.." Heap="..node.heap())
if ix > 0 then
	local o1=77;local o2=109;local o3=101;o4=53;local o5=57;local o6=61; local o7=65
	if t2[ix] >= tonumber(string.sub(s_d,o1,o1+3),16) then trace("Time"..t2[ix].."-"..tonumber(string.sub(s_d,o1,o1+3),16));return end
	local d=inv_sn[ix]
	local function a2d(dc,dd)
		d=d..","..tonumber(string.format("%."..dc.."f",dd))
	end
	a2d(2,tonumber(string.sub(s_d,73,76),16)/100)
	a2d(1,0.0198*tonumber(string.sub(s_d,97,100),16)-23.84)
	a2d(1,tonumber(string.sub(s_d,69,72),16)/3.75)
 	t1[ix]=t2[ix];t2[ix]=tonumber(string.sub(s_d,o1,o1+3),16)
	e11[ix]=e12[ix];e12[ix]=tonumber(string.sub(s_d,o2,o2+7),16)/65535
	a2d(1,((e12[ix]-e11[ix]))*3600/(t2[ix]-t1[ix]))
	e21[ix]=e22[ix];e22[ix]=tonumber(string.sub(s_d,o3,o3+7),16)/65535
	a2d(1,((e22[ix]-e21[ix]))*3600/(t2[ix]-t1[ix]))
	a2d(2,e12[ix]/1000);a2d(2,e22[ix]/1000)
	a2d(1,tonumber(string.sub(s_d,o6,o6+3),16)/80)
	a2d(1,tonumber(string.sub(s_d,o7,o7+3),16)/80)
	a2d(1,tonumber(string.sub(s_d,o4,o4+3),16)/48)
	a2d(1,tonumber(string.sub(s_d,o5,o5+3),16)/48)
	-- a2d(1,tonumber(string.sub(s_d,81,84),16)) AC Power
	trace(d);s_inv_d[ix]=d;assert(loadfile("upload.lua"))(d)
end
