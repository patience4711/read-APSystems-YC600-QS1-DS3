trace("Executing health check")
hour=hour+1
local conn=net.createConnection(net.TCP,0)
conn:on("receive",function(conn,payload)
	hour=string.sub(string.sub(payload,string.find(payload,"Date: ")+23,string.find(payload,"Date: ")+30),1,2)+2
	trace("Hour: "..hour)
	if hour == 2 then 
		trace("Reset counters")
		for j=1, inv_num do e11[j]=0;e21[j]=0;e12[j]=0;e22[j]=0;e31[j]=0;e41[j]=0;e32[j]=0;e42[j]=0;t0[j]=0;t1[j]=0;t2[j]=0 end
	end
    	conn:close()
end)
conn:on("connection",function(conn, payload)
	conn:send("HEAD / HTTP/1.1\r\nHost: google.com\r\nAccept: */*\r\n"..
	"User-Agent: Mozilla/4.0 (compatible; esp8266 Lua;)\r\n\r\n") end)  
conn:connect(80,"google.com")
if node.heap() < 15000 then trace("Restart. Heap: "..node.heap()) node.restart() end
