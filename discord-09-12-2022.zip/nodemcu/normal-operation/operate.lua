hour=12
local h_check=tmr.create()
h_check:register(3600000,tmr.ALARM_AUTO,function() dofile("h_check.lua") end)
h_check:start()

local ccmd={}
for x=1, inv_num do
	ccmd[x]="2401"..string.sub(inv_id[x],3,4)..string.sub(inv_id[x],1,2).."1414060001000F13"..string.sub(ecu_id,11,12)..string.sub(ecu_id,9,10)..string.sub(ecu_id,7,8)..string.sub(ecu_id,5,6)..string.sub(ecu_id,3,4)..string.sub(ecu_id,1,2).."FBFB06BB000000000000C1FEFE"
end

local s_data=""
local parse_im=tmr.create()
parse_im:register(1000,tmr.ALARM_AUTO,function()
	if string.len(s_data) > 0 then
		local a,b=string.find(s_data,":")
		if a ~= nil and b ~= nil then
			local str=string.sub(s_data,1,a-1)
			s_data=string.sub(s_data,b+1,string.len(s_data))
			trace("Parsing data. "..str.." Heap="..node.heap())
			if string.sub(str,5,8) == "4481" then
				trace("Found 4481. Heap="..node.heap())
				local ln=string.len(str)
				local fcs=string.sub(str,ln-1,ln)
				if crc(string.sub(str,5,ln-2)) == fcs then
					if ln == 238 then assert(loadfile("calculate.lua"))(str) end
					if ln == 260 then assert(loadfile("calculat2.lua"))(str) end
				end
			end
		else s_data="" end
	end
end)
parse_im:start()
local mytimer0=tmr.create()
mytimer0:register(u_delay,tmr.ALARM_AUTO,function()
	if not stealth then send_command("FE"..sln(ccmd[state])..ccmd[state]..crc(ccmd[state])) end
	state=state+1
	if state > inv_num then state = 1 end
end)
local mytimer=tmr.create()
mytimer:register(5000,tmr.ALARM_SINGLE,function(t)
	trace("Quering data. Heap="..node.heap())
	local receive=0;local r_data="";local lng=0
	uart.on("data",1,function(s)
		if receive == 2 then
			r_data=r_data..tohex(s);lng=lng-1
			if lng == 0 then
				receive=0;s_data=s_data..r_data..":"
			end
		else
			if receive == 1 then
				lng=tonumber(tohex(s),16)+3
				receive=2;r_data=r_data..tohex(s)
			else
				if tohex(s) == "FE" then
					receive=1;r_data="FE"
				else
					--skip
				end
			end
		end
	end,0)
        state=1;mytimer0:start()
end)
mytimer:start()
