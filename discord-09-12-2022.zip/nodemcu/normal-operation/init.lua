uart.setup(0,115200,8,0,1,1)
node.setcpufreq(node.CPU160MHZ)

station_cfg={}
station_cfg.ssid="your-wifi"
station_cfg.pwd="your-pwd"
wifi.sta.config(station_cfg)
wifi.sta.connect()
wifi.sta.setip({ip="your-ip",netmask="255.255.255.0",gateway="your-gw"})

server="your-mqtt-broker";usr="mqtt-user";pass="mqtt-pwd"

ecu_id="D8A3011B9780"
inv_sn={};inv_id={}
inv_num=2
inv_sn[1]="408000066781";inv_id[1]="C28C"
inv_sn[2]="408000082558";inv_id[2]="A595"
stealth=false
u_delay=60000
trace_on=false
trf="trace.txt"
if trace_on then
	file.open(trf,"a")
	file.writeline(tmr.time()..": Starting up. Heap="..node.heap());file.close()
end

state=0;e11={};e21={};e12={};e22={};e31={};e41={};e32={};e42={};t0={};t1={};t2={};s_inv_d={}
for j=1, inv_num do
	e11[j]=0;e21[j]=0;e12[j]=0;e22[j]=0;e31[j]=0;e41[j]=0;e32[j]=0;e42[j]=0;t0[j]=0;t1[j]=0;t2[j]=0;s_inv_d[j]=""
end

function trace(l)
	if trace_on then
		file.open(trf,"a");file.writeline(tmr.time()..": "..l);file.close()
	end
end

function fhex(str) return (str:gsub('..',function(cc)
	return string.char(tonumber(cc,16)) end))
end

function tohex(str) return (str:gsub('.',function(c)
	return string.format('%02X',string.byte(c)) end))
end

function sln(str)
	local l=string.format("%02x",string.len(str)/2-2)
	return string.upper(l)
end

function crc(str)
	str=sln(str)..str
	local crc=string.sub(str,0,2)
	for i=1, string.len(str)/2-1 do
		crc=string.format("%02x",bit.bxor(tonumber(crc,16),tonumber(string.sub(str,i*2+1,i*2+2),16)))
	end
	return string.upper(crc)
end

function send_command(str)
	trace("Sent="..str);uart.write(0,fhex(str))
end

local cctimer=tmr.create()
cctimer:register(2000,tmr.ALARM_SINGLE,function()
	trace("Finished. Heap="..node.heap())
	dofile("initialize.lua")
end)

local httptimer=tmr.create()
httptimer:register(2000,tmr.ALARM_SINGLE,function()
	dofile("httpserv.lua")
	cctimer:start()
end)

local wifitimer=tmr.create()
wifitimer:register(1000,tmr.ALARM_AUTO,function()
	if wifi.sta.getip() == nil then
		print("Connecting to AP...")
	else
		gpio.mode(4,gpio.OUTPUT)
		gpio.write(4,gpio.LOW)
		print("Got IP: "..wifi.sta.getip())
		httptimer:start()
		wifitimer:unregister()
	end
end)
wifitimer:start()
