uart.alt(1)

local state=0
local ccmd={}
ccmd[0]=9
ccmd[1]="2605030103"
ccmd[2]="410000"
ccmd[3]="26050108FFFF"..string.sub(ecu_id,11,12)..string.sub(ecu_id,9,10)..string.sub(ecu_id,7,8)..string.sub(ecu_id,5,6)..string.sub(ecu_id,3,4)..string.sub(ecu_id,1,2)
ccmd[4]="2605870100"
ccmd[5]="26058302"..string.sub(ecu_id,1,2)..string.sub(ecu_id,3,4)
ccmd[6]="2605840400000100"
ccmd[7]="240014050F00010100020000150000"
ccmd[8]="2600"
ccmd[9]="6700"

s_data=""
parse_im=tmr.create()
parse_im:register(1000,tmr.ALARM_AUTO,function()
	local str=s_data;s_data="" 
	if string.len(str) > 0 then
		trace("Received="..str)
		if string.sub(str,5,8) == "4481" and string.sub(str,17,20) ~= "0000" then
			trace("Found inverter: 0x"..string.sub(str,19,20)..string.sub(str,17,18))
		end
	end
end)
parse_im:start()

local mytimer2=tmr.create()
mytimer2:register(5000,tmr.ALARM_SINGLE,function() 
	blink:stop();gpio.write(4,gpio.LOW)
	trace("Finished. Heap="..node.heap())
end)

local mytimer1=tmr.create()
mytimer1:register(5000,tmr.ALARM_AUTO,function() 
	if state == 0 then
		send_command("FE"..sln(ccmd[2])..ccmd[2]..crc(ccmd[2]))
	else
		send_command("FE"..sln(ccmd[state])..ccmd[state]..crc(ccmd[state]))
	end
	if (state == ccmd[0]) then
		state=0;mytimer2:start();mytimer1:unregister()
	end
	state=state+1
end)

local mytimer0=tmr.create()
mytimer0:register(5000,tmr.ALARM_AUTO,function() 
	send_command("FE"..sln(ccmd[2])..ccmd[2]..crc(ccmd[2]))
	state=state+1
	if state > 2 then
		state=0;mytimer1:start();mytimer0:unregister()
	end
end)

local mytimer=tmr.create()
mytimer:register(1000,tmr.ALARM_SINGLE,function(t)
	blink:start()
	trace("Starting CC2530. Heap="..node.heap()) 
	local receive=0;local r_data="";local lng=0
	uart.on("data",1,function(s)
		if receive == 2 then
			r_data=r_data..tohex(s);lng=lng-1
			if lng == 0 then
				receive=0;s_data=r_data
			end
		else
			if receive == 1 then
				lng=tonumber(tohex(s),16)+3
				receive=2;r_data=r_data..tohex(s)
			else
				if tohex(s) == "FE" then
					receive=1;r_data="FE"
				else 
					--skip 
				end
			end
		end
	end,0)
        mytimer0:start()
end)
uart.setup(0,115200,8,0,1,1)
mytimer:start()
