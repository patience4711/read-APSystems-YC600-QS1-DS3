inv_id=...
if inv_id == nil or string.len(inv_id) ~= 4 then
	if inv_id == nil then trace("Missing inverter ID.")
	else trace("Incorrect inverter ID: "..inv_id) end
	trace("Example: http://"..wifi.sta.getip().."/reboot.lua?C28C, /reboot.lua?A595, etc.")
	return
else trace("Rebooting inverter with ID="..inv_id) end

local state=1
local ccmd={}
ccmd[0]=1
ccmd[1]="2401"..string.sub(inv_id,3,4)..string.sub(inv_id,1,2).."1414060001000F13"..string.sub(ecu_id,11,12)..string.sub(ecu_id,9,10)..string.sub(ecu_id,7,8)..string.sub(ecu_id,5,6)..string.sub(ecu_id,3,4)..string.sub(ecu_id,1,2).."FBFB06C1000000000000A6FEFE"
inv_id=nil

local mytimer1=tmr.create()
mytimer1:register(5000,tmr.ALARM_SINGLE,function() 
	trace("Finished. Heap="..node.heap())
	blink:stop();gpio.write(4,gpio.LOW)
end)

local mytimer0=tmr.create()
mytimer0:register(5000,tmr.ALARM_AUTO,function() 
	send_command("FE"..sln(ccmd[state])..ccmd[state]..crc(ccmd[state]))
	if (state == ccmd[0]) then mytimer1:start();mytimer0:unregister() end
	state=state+1
end)

local mytimer=tmr.create()
mytimer:register(1000,tmr.ALARM_SINGLE,function(t)
	trace("Rebooting started. Heap="..node.heap())
	blink:start()
        mytimer0:start()
end)
uart.setup(0,115200,8,0,1,1)
mytimer:start()
