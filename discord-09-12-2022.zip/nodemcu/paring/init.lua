uart.setup(0,115200,8,0,1,1)
node.setcpufreq(node.CPU160MHZ)

ecu_id="D8A3011B9780"

station_cfg={}
station_cfg.ssid="your-wifi"
station_cfg.pwd="your-pwd"
wifi.setphymode(wifi.PHYMODE_B)
wifi.setmode(wifi.STATION,false)
wifi.sta.config(station_cfg)
wifi.sta.connect()
--wifi.sta.setip({ip="your-ip",netmask="255.255.255.0",gateway="your-gateway"})

trace_on=true
trf="trace.txt"
if trace_on then
	file.open(trf,"w")
	file.writeline(tmr.time()..": Starting up. Heap="..node.heap());file.close()
end

function trace(l)
	if trace_on then
		file.open(trf,"a");file.writeline(tmr.time()..": "..l);file.close()
	end
end

function fhex(str) return (str:gsub('..', function(cc)
	return string.char(tonumber(cc,16)) end))
end

function tohex(str) return (str:gsub('.',function(c)
	return string.format('%02X',string.byte(c)) end))
end

function sln(str)
	local l=string.format("%02x",string.len(str)/2-2)
	return string.upper(l)
end

function crc(str)
	str=sln(str)..str 
	local crc=string.sub(str,0,2)
	for i=1, string.len(str)/2-1 do
		crc=string.format("%02x",bit.bxor(tonumber(crc,16),tonumber(string.sub(str,i*2+1,i*2+2),16)))
	end
	return string.upper(crc)
end

function send_command(str)
	trace("Sent="..str);uart.write(0,fhex(str))
end

blink=tmr.create()
blink:register(500,tmr.ALARM_AUTO,function()
	if gpio.read(4) == gpio.HIGH then gpio.write(4,gpio.LOW)
	else gpio.write(4,gpio.HIGH) end
end)

local cctimer=tmr.create()
cctimer:register(2000,tmr.ALARM_SINGLE,function() 
	print("When the blue LED is not flashing any more, type")
	print("http://"..wifi.sta.getip().." in your browser.")
	dofile("initialize.lua")
end)

local httptimer=tmr.create()
httptimer:register(2000,tmr.ALARM_SINGLE,function() 
	dofile("httpserv.lua")
	cctimer:start()
end)

local wifitimer=tmr.create()
wifitimer:register(1000,tmr.ALARM_AUTO,function() 
	if wifi.sta.getip() == nil then
		print("Connecting to AP...")
	else
		local ip,nm,gw = wifi.sta.getip()
		gpio.mode(4,gpio.OUTPUT)
		gpio.write(4,gpio.LOW)
		print("Got IP: "..wifi.sta.getip())
		httptimer:start()
		wifitimer:unregister()
	end
end)
wifitimer:start()
