inv_sn=...
if inv_sn == nil or string.len(inv_sn) ~= 12 or not string.find(inv_sn,"^[+-]?%d+$") then
	if inv_sn == nil then trace("Missing inverter serial number.")
	else trace("Incorrect inverter serial number: "..inv_sn) end
	trace("Example: http://"..wifi.sta.getip().."/pair.lua?408000066782")
	return
else trace("Pairing inverter with number="..inv_sn) end

local state=1
local ccmd={}
ccmd[0]=5
ccmd[1]="6700"
ccmd[2]="24020FFFFFFFFFFFFFFFFF14FFFF140D0200000F1100"..inv_sn.."FFFF10FFFF"..string.sub(ecu_id,11,12)..string.sub(ecu_id,9,10)..string.sub(ecu_id,7,8)..string.sub(ecu_id,5,6)..string.sub(ecu_id,3,4)..string.sub(ecu_id,1,2)
ccmd[3]="24020FFFFFFFFFFFFFFFFF14FFFF140C0201000F0600"..inv_sn
ccmd[4]="24020FFFFFFFFFFFFFFFFF14FFFF140F0102000F1100"..inv_sn..string.sub(ecu_id,3,4)..string.sub(ecu_id,1,2).."10FFFF"..string.sub(ecu_id,11,12)..string.sub(ecu_id,9,10)..string.sub(ecu_id,7,8)..string.sub(ecu_id,5,6)..string.sub(ecu_id,3,4)..string.sub(ecu_id,1,2)
ccmd[5]="24020FFFFFFFFFFFFFFFFF14FFFF14010103000F0600"..string.sub(ecu_id,11,12)..string.sub(ecu_id,9,10)..string.sub(ecu_id,7,8)..string.sub(ecu_id,5,6)..string.sub(ecu_id,3,4)..string.sub(ecu_id,1,2)
inv_sn=nil

local mytimer1=tmr.create()
mytimer1:register(5000,tmr.ALARM_SINGLE,function() 
	trace("Finished. Heap="..node.heap())
	blink:stop();gpio.write(4,gpio.LOW)
end)

local mytimer0=tmr.create()
mytimer0:register(5000,tmr.ALARM_AUTO,function() 
	send_command("FE"..sln(ccmd[state])..ccmd[state]..crc(ccmd[state]))
	if (state == ccmd[0]) then mytimer1:start();mytimer0:unregister() end
	state=state+1
end)

local mytimer=tmr.create()
mytimer:register(1000,tmr.ALARM_SINGLE,function(t)
	trace("Pairing started. Heap="..node.heap())
	blink:start()
        mytimer0:start()
end)
uart.setup(0,115200,8,0,1,1)
mytimer:start()
