print("Starting HTTP server")
local function Sendfile(client,filename)
	local ftr=file.open(filename,"r")
	if ftr then
		local function sendChunk() 
			local line=ftr:read(512)
			if line then client:send(line,sendChunk)
			else ftr:close();client:close();line=nil end
		end
		local ctype="text/txt";ctype=string.upper(filename:match("^.+(%..+)$"))
		if ctype == ".HTM" or ctype == ".HTML" then ctype="text/html" end
		if ctype == ".TXT" then ctype="text/plain" end
		client:send("HTTP/1.1 200 OK\r\n Server: NodeMCU on ESP8266\r\nContent-Type: "..ctype.."; charset=UTF-8\r\n\r\n",sendChunk)
	else
		client:on("sent",function(sck) sck:close() end)
		client:send("HTTP/1.0 404 Not Found\r\n\r\nPage not found")
	end
end
local srv=net.createServer(net.TCP)
srv:listen(80,function(conn)
	conn:on("receive",function(client,request)
		local path=string.match(request,"GET /(.+) HTTP")
		local t={};local i=1;local para=""
		if path == nil or path == "" or path == "/" then 
			path="temp.txt";local ftw=file.open(path,"w")
			ftw:writeline("NodeMCU on ESP8266\r\n")
			ftw:writeline("Pair you ECU ("..ecu_id..") with an inverter: http://"..wifi.sta.getip().."/pair.lua?<serial number of inverter>\r\n")
			ftw:writeline("Reboot your inverter: http://"..wifi.sta.getip().."/reboot.lua?<ID of inverter> (e.g. A595)\r\n")
			ftw:writeline("Examples: http://"..wifi.sta.getip().."/pair.lua?408000066782 or http://"..wifi.sta.getip().."/reboot.lua?C28C\r\n")
			ftw:writeline("Display logging: http://"..wifi.sta.getip().."/trace.txt\r\n")
			ftw:close()
		else
			for str in string.gmatch(path,"([^".."?".."]+)") do
				t[i]=str;i=i+1
			end
			if t[1] then path=t[1] end
			if t[2] then para=t[2] end
		end
		local ext=path:match("^.+(%..+)$")
		if ext ~= nil then 
			if string.upper(ext) == ".LUA" then
				local ftr=file.open(path,"r")
				if ftr then
					ftr:close();local ftw=file.open("temp.txt","w")
					ftw:writeline("Executing "..path..". Wait until the blue LED is flashing!\r\n")
					ftw:writeline("Display outcome of process: http://"..wifi.sta.getip().."/trace.txt\r\n")
					ftw:close()
					if para then assert(loadfile(path))(para)
					else dofile(path) end
				else
					ftw=file.open("temp.txt","w")
					ftw:writeline("Cannot find "..path.."\r\n")
					ftw:close()
				end
				path="temp.txt"
			end
		end
		Sendfile(client,path)
	end)
end)
print("HTTP Server is running")
