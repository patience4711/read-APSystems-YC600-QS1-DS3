NODEMCU implementation of pairing ECU and rebooting your inverter
=================================================================

1. Setup

Flash ESP8266 with attached firmware
Edit header of init.lua to include your wifi credentials and ECU ID
Upload all the lua files to the ESP
Connect the radio device RX to D7, TX to D8 of the ESP8266, VCC to 3.3V, 
GND to GND.

If everything is setup correctly the ECU will start up when you power up 
the ESP. The blued led will blink until the radio device is properly 
configured. Wait patiently, it will take approximately 80 sec for startup. 
If the blue led shows no activity at all, check your setup/wiring.


2. Operation

If the device has succesfully finished initialization, the blue led will stay 
on. Open your web browser and navigate to the IP address of your NODEMCU:

Example URL: http://192.168.0.201. Here you should see a similar page:

NodeMCU on ESP8266
Pair you ECU (D8A3011B9780) with an inverter: http://192.168.0.51/pair.lua?<serial number of inverter>
Reboot your inverter: http://192.168.0.51/reboot.lua?<ID of inverter> (e.g. A595)
Examples: http://192.168.0.51/pair.lua?408000066782 or http://192.168.0.51/reboot.lua?C28C

To start pairing, load the pair.lua script with the serial number of your 
inverter as parameter. Please follow the above format properly, otherwise 
pairing will not work. In case pairing has started, the blue led will again 
blink until the process completes. When the blue led has finished blinking 
and is on again, load trace.txt to see the results.

A correct initialization and pairing process will look like similar to this:

0: Starting up. Heap=32392
10: Starting CC2530. Heap=22840
15: Sent=FE0141000040
15: Received=FE064180020202020702C2
20: Sent=FE0141000040
20: Received=FE064180020202020702C2
25: Sent=FE0141000040
25: Received=FE064180020202020702C2
30: Sent=FE0141000040
30: Received=FE064180020202020702C2
35: Sent=FE03260503010321
35: Received=FE0166050062
40: Sent=FE0141000040
40: Received=FE064180020202020702C2
45: Sent=FE0A26050108FFFF80971B01A3D856
45: Received=FE0166050062
50: Sent=FE032605870100A6
50: Received=FE0166050062
55: Sent=FE0426058302D8A3DD
55: Received=FE0166050062
60: Sent=FE062605840400000100A4
60: Received=FE0166050062
65: Sent=FE0D240014050F0001010002000015000020
65: Received=FE0164000065
70: Sent=FE00260026
71: Received=FE00660066
71: Received=FE0145C0088C
71: Received=FE0145C0088C
71: Received=FE0145C0088C
72: Received=FE0145C0088C
72: Received=FE0145C0088C
72: Received=FE0145C0088C
72: Received=FE0145C0088C
73: Received=FE0145C0098D
74: Finished. Heap=27312
112: Pairing serial number=408000119348
113: Starting pairing. Heap=24320
118: Sent=FE00670067
118: Received=FE0E670000FFFF80971B01A3D8000007090011
123: Sent=FE2524020FFFFFFFFFFFFFFFFF14FFFF140D0200000F1100408000119348FFFF10FFFF80971B01A3D871
124: Received=FE25448100000D0200001414012700130004000011408000119348FFFF10FFFF80971B01A3D83A7C0DE8
128: Sent=FE1A24020FFFFFFFFFFFFFFFFF14FFFF140C0201000F06004080001193483F
128: Received=FE0164020067
129: Received=FE1A448100000C02000014140122003F420400000640800011934821D00D7B
133: Sent=FE2524020FFFFFFFFFFFFFFFFF14FFFF140F0102000F1100408000119348A3D810FFFF80971B01A3D809
134: Received=FE1C4481000001013A7C14140024004E8204000008FFFF4080001193483A7C0E39
134: Inverter ID: 0x7C3A
138: Sent=FE1A24020FFFFFFFFFFFFFFFFF14FFFF14010103000F060080971B01A3D84F
138: Received=FE1A44810000010100001414012700CEB60400000680971B01A3D83A7C0DBE
143: Finished. Heap=26368

Save the Inverter ID from the log (in the example log above 0x7C3A). 
You will need it for the normal operation.

You may also use the same setup to reboot an inverter. If you want to do so,
use reboot.lua instead of pair.lua and pass the 4 digits of the Inverter ID.

Example: http://192.168.0.201/reboot.lua?C28C

Once the LED stops flashing you may check trace.txt for more info.


3. Which script does what

init.lua - NODEMCU start this program when powered on. If you want to regain
control, delete this within 5 sec of starting up your NODEMCU
initialize.lua - brings up the coordinator (fake ECU)
pair.lua - pairs an inverter
httpserv.lua - minimal http server
reboot.lua - reboots an inverter


4. Avoid using ESPlorer:

ESPlorer has a problem with uploading lua scripts to NodeMCU. Please consider 
using an other tool, like https://www.npmjs.com/package/nodemcu-tool. If you 
still want to stick with ESPlorer, make sure you switch on "turbo mode" before 
uploading anything. Otherwise, scripts might get corrupted and your setup will 
disfunction. https://www.esp8266.com/viewtopic.php?f=22&t=1166&start=4 
