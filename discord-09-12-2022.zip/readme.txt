cc253x-firmware: Radio device firmwares. Flash one of these, standard Zigbee firmware will not work!

z-tool: CC2531+PC implementation for pairing (YC600 & QS1) and normal operation (only YC600 & DS3 test version)

nodemcu: NodeMCU (LUA) implementation. For pairing (YC600, QS1 & DS3) and normal operation (YC600, QS1 & DS3). 

